const global = {
    datetimeFormat: 'D MMM YYYY h:mm A'
}

export default global;