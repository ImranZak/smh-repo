import React from 'react'

function Homepage() {
  return (
    <div>Welcome to Sustainability Management Hub!</div>
  )
}

export default Homepage